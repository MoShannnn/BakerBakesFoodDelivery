<?php
    include('../connection.php');
    $sql = "DELETE FROM product where prod_id='".$_GET['prod_id']."'";
    $query = $dbConn->prepare($sql);
    $query->execute();

    header('location:product.php');
?>
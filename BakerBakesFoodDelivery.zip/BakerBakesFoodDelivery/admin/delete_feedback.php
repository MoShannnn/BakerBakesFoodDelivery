<?php
    include('../connection.php');
    $sql = "DELETE FROM contact_message where id='".$_GET['id']."'";
    $query = $dbConn->prepare($sql);
    $query->execute();

    header('location:feedback.php');
?>
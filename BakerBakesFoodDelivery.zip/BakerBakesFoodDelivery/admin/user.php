<?php
    session_start();
    if(isset($_SESSION['username'])){
        include('header.php');
        include("../connection.php");
        $sql = "SELECT * FROM register";
        $query = $dbConn->prepare($sql);
        $query->execute();
        $result = $query->fetchAll();
?>
<body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 bg-dark wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 mt-2 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
            <h3 class="text-primary" style="font-size:16pt; margin-left: 35px; margin-top: -5px;">Food Delivery</h3>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="home.php" class="nav-item nav-link">Home</a>
                <a href="user.php" class="nav-item nav-link active">User</a>
                <a href="product.php" class="nav-item nav-link">Product</a>
                <a href="orderlist.php" class="nav-item nav-link">Order List</a>
                <a href="feedback.php" class="nav-item nav-link">Feedback</a>
                <a href="../logout.php" class="btn btn-primary rounded-pill my-auto" style="margin-left: 20px;padding: 8px; width: 80px; height: 50px;">Log Out</a>
            </div>
    </nav>
    <!-- Navbar End -->


    <div class="container my-5">
        <div class="row py-5">
            <div class="col-md-10 my-5 mx-auto">
                <a href="create_user.php" class="btn btn-success float-end my-3">Add New User  <i class="bi bi-plus-circle-fill"></i></a>
                <table class="table table-bordered table-striped">
                    <tr class="text-center">
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Action</th>
                    </tr>
                    <?php
                        foreach ($result as $key => $value) {
                    ?>
                        <tr>
                            <td>
                                <?php echo $value['first_name'];?>
                            </td>
                            <td>
                                <?php echo $value['last_name'];?>
                            </td>
                            <td>
                                <?php echo $value['email'];?>
                            </td>
                            <td>
                                <?php echo $value['password'];?>
                            </td>
                            <td class="text-center">
                                <a href="delete_user.php?id=<?php echo $value['id'];?>" class="btn btn-primary">Delete  <i class="bi bi-trash-fill"></i></a>
                            </td>
                        </tr>
                    <?php
                        }
                    ?>
                </table>
            </div>
        </div>
    </div>

<?php
    include("footer.php");
    }
    else{
        header('location:index.php');
    }
?>
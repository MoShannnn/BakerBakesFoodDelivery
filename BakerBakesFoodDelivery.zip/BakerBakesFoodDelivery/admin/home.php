<?php
    session_start();
    if(isset($_SESSION['username'])){
        include('header.php');
?>
<body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 bg-dark wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 mt-2 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
            <h3 class="text-primary" style="font-size:16pt; margin-left: 35px; margin-top: -5px;">Food Delivery</h3>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="home.php" class="nav-item nav-link active">Home</a>
                <a href="user.php" class="nav-item nav-link">User</a>
                <a href="product.php" class="nav-item nav-link">Product</a>
                <a href="orderlist.php" class="nav-item nav-link">Order List</a>
                <a href="feedback.php" class="nav-item nav-link">Feedback</a>
                <a href="../logout.php" class="btn btn-primary rounded-pill my-auto" style="margin-left: 20px;padding: 8px; width: 80px; height: 50px;">Log Out</a>
            </div>
    </nav>
    <!-- Navbar End -->

    <div class="container adminhome mx-auto">
        <h1>Hello!! Welcome to <span style="font-size: 20pt;">Baker Bakes Food Delivery's</span> Admin Page.</h1>
    </div>
<?php
    include("footer.php");
    }
    else{
        header('location:index.php');
    }
?>
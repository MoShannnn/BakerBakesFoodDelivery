<?php
    include('../connection.php');
    $sql = "DELETE FROM bakery_order where id='".$_GET['id']."'";
    $query = $dbConn->prepare($sql);
    $query->execute();

    header('location:orderlist.php');
?>
<?php
    include('../connection.php');
    $sql = "DELETE FROM register where id='".$_GET['id']."'";
    $query = $dbConn->prepare($sql);
    $query->execute();

    header('location:user.php');
?>
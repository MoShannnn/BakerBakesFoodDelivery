<?php 
    session_start();
    if(isset($_SESSION['username'])){
        include("header.php");
        include("../connection.php");
        if(isset($_POST['save_user'])){
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $email = $_POST['email'];
            $password = $_POST['password'];
        
            $stmt = $dbConn->prepare("SELECT * FROM register WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
        
            if ($stmt->rowCount() > 0) {
                $error = "User Email already exists";
            } else {
                $stmt = $dbConn->prepare("INSERT INTO register (first_name, last_name, email, password) VALUES (:first_name, :last_name, :email, :password)");
                $stmt->bindParam(':first_name', $first_name);
                $stmt->bindParam(':last_name', $last_name);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $password);
        
                if ($stmt->execute()) {
                    header("location:user.php");
                    exit;
                } else {
                    $error = "Error creating account";
                }
            }
        }
?>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 bg-dark wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 mt-2 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
            <h3 class="text-primary" style="font-size:16pt; margin-left: 35px; margin-top: -5px;">Food Delivery</h3>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="home.php" class="nav-item nav-link">Home</a>
                <a href="user.php" class="nav-item nav-link active">User</a>
                <a href="product.php" class="nav-item nav-link">Product</a>
                <a href="orderlist.php" class="nav-item nav-link">Order List</a>
                <a href="feedback.php" class="nav-item nav-link">Feedback</a>
                <a href="../logout.php" class="btn btn-primary rounded-pill my-auto" style="margin-left: 20px;padding: 8px; width: 80px; height: 50px;">Log Out</a>
            </div>
    </nav>
    <!-- Navbar End -->

    <h2 class="mb-4 bg-light text-dark text-center my-5" style="padding: 60px 0px 20px;">Add a New User</h2>
    <div class="container my-5">
        <div class="col-md-6 mx-auto">
        <form action="create_user.php" method="post">
        <div class="mb-3">
        <label for="first_name" class="form-label">First name</label>
        <input type="text" name="first_name" id="first_name" class="form-control" placeholder="" required aria-describedby="helpId">
        </div>
        <div class="mb-3">
        <label for="last_name" class="form-label">Last name</label>
        <input type="text" name="last_name" id="last_name" class="form-control" placeholder="" required aria-describedby="helpId">
        </div>
        <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="text" name="email" id="email" class="form-control" placeholder="" required aria-describedby="helpId">
        </div>
        <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="text" name="password" id="password" class="form-control" placeholder="" required aria-describedby="helpId">
        </div>
        <input type="submit" name="save_user" value="Save User" class="btn btn-primary">
        <button class="btn" onclick="goBack()">Go Back</button>
    </form>
        </div>
    </div>
<script>
    function goBack() {
    window.history.back();
    }
</script>
<?php
    include("footer.php");
    }
    else{
        header('location:index.php');
    }
?>
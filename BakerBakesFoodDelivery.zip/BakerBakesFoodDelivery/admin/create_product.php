<?php 
    session_start();
    if(isset($_SESSION['username'])){
        error_reporting(1);
        include("header.php");
        include("../connection.php");
        if(isset($_POST['save_prod'])){
            $prod_name = $_POST['prod_name'];
            $prod_price = $_POST['prod_price'];
            $prod_description = $_POST['prod_description'];
            $filename = $_FILES['prod_img']['name'];
            $extension = pathinfo($filename, PATHINFO_EXTENSION);
            $prod_img = uniqid().'.'.$extension;


            $stmt = $dbConn->prepare("SELECT * FROM product WHERE prod_name = :prod_name");
            $stmt->bindParam(':prod_name', $prod_name);
            $stmt->execute();
        
            if ($stmt->rowCount() > 0) {
                $error = "Product Name already exists";
            } else {
                $stmt = $dbConn->prepare("INSERT INTO product (prod_name, prod_price, prod_description, prod_img) VALUES (:prod_name, :prod_price, :prod_description, :prod_img)");
                $stmt->bindParam(':prod_name', $prod_name);
                $stmt->bindParam(':prod_price', $prod_price);
                $stmt->bindParam(':prod_description', $prod_description);
                $stmt->bindParam(':prod_img', $prod_img);
        
                if ($stmt->execute()) {
                    mkdir("../images/products/$i");
                    move_uploaded_file($_FILES['prod_img']['tmp_name'], "../images/products/$prod_img");
                    header("location:product.php");
                    exit;
                } else {
                    $error = "Error Occur when adding product!!";
                }
            }
        }
?>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 bg-dark wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 mt-2 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
            <h3 class="text-primary" style="font-size:16pt; margin-left: 35px; margin-top: -5px;">Food Delivery</h3>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="home.php" class="nav-item nav-link">Home</a>
                <a href="user.php" class="nav-item nav-link">User</a>
                <a href="product.php" class="nav-item nav-link active">Product</a>
                <a href="orderlist.php" class="nav-item nav-link">Order List</a>
                <a href="feedback.php" class="nav-item nav-link">Feedback</a>
                <a href="../logout.php" class="btn btn-primary rounded-pill my-auto" style="margin-left: 20px;padding: 8px; width: 80px; height: 50px;">Log Out</a>
            </div>
    </nav>
    <!-- Navbar End -->

    <h2 class="mb-4 bg-light text-dark text-center my-5" style="padding: 60px 0px 20px;">Add a New Product</h2>
    <div class="container my-5">
        <div class="col-md-6 mx-auto">
        <form action="create_product.php" method="post" enctype="multipart/form-data">
        <div class="mb-3">
        <label for="prod_name" class="form-label">Product Name</label>
        <input type="text" name="prod_name" id="prod_name" class="form-control" placeholder="" required aria-describedby="helpId">
        </div>
        <div class="mb-3">
        <label for="prod_price" class="form-label">Prodcut Price</label>
        <input type="text" name="prod_price" id="prod_price" class="form-control" placeholder="" required aria-describedby="helpId">
        </div>
        <div class="mb-3">
        <label for="prod_description" class="form-label">Product Description</label>
        <input type="text" name="prod_description" id="prod_description" class="form-control" placeholder="" required aria-describedby="helpId">
        </div>
        <div class="mb-3">
        <label for="prod_img" class="form-label">Product Image</label>
        <input type="file" name="prod_img" id="prod_img" class="form-control" placeholder="" aria-describedby="helpId">
        </div>
        <input type="submit" name="save_prod" value="Save Product" class="btn btn-primary">
        <button class="btn" onclick="goBack()">Go Back</button>
        </form>
        </div>
        <h3 class="text-center mt-5 text-primary bg-dark"><?php echo $error; ?></h3>
    </div>
<script>
    function goBack() {
    window.history.back();
    }
</script>
<?php
    include("footer.php");
    }
    else{
        header('location:index.php');
    }
?>
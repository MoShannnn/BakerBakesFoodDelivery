<?php
    session_start();
    if(isset($_SESSION['username'])){
        include('header.php');
        include("../connection.php");
        $sql = "SELECT * FROM product";
        $query = $dbConn->prepare($sql);
        $query->execute();
        $result = $query->fetchAll();
?>
<body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 bg-dark wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 mt-2 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
            <h3 class="text-primary" style="font-size:16pt; margin-left: 35px; margin-top: -5px;">Food Delivery</h3>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="home.php" class="nav-item nav-link">Home</a>
                <a href="user.php" class="nav-item nav-link">User</a>
                <a href="product.php" class="nav-item nav-link active">Product</a>
                <a href="orderlist.php" class="nav-item nav-link">Order List</a>
                <a href="feedback.php" class="nav-item nav-link">Feedback</a>
                <a href="../logout.php" class="btn btn-primary rounded-pill my-auto" style="margin-left: 20px;padding: 8px; width: 80px; height: 50px;">Log Out</a>
            </div>
    </nav>
    <!-- Navbar End -->


    <div class="container my-5">
        <div class="row py-5">
            <div class="col-md-10 my-5 mx-auto">
                <a href="create_product.php" class="btn btn-success float-end my-3">Add New Product  <i class="bi bi-plus-circle-fill"></i></a>
                <table class="table table-bordered table-striped">
                    <tr class="text-center">
                        <th>Product Name</th>
                        <th>Product Image</th>
                        <th>Product Price</th>
                        <th>Product Description</th>
                        <th>Action</th>
                    </tr>
                    <?php
                        foreach ($result as $key => $value) {
                    ?>
                        <tr>
                            <td class="col-md-2 text-center">
                                <?php echo $value['prod_name'];?>
                            </td>
                            <td class="col-md-3 text-center">
                                <img src="../images/products/<?php echo $value['prod_img'];?>" alt="Pitch Image" style="width: 80%;height: 180px;">  
                            </td>
                            <td class="col-md-2 text-center">
                                <?php echo $value['prod_price'];?>
                            </td>
                            <td class="col-md-3">
                                <?php echo $value['prod_description'];?>
                            </td>
                            <td class="col-md-2 text-center">
                                <a href="delete_product.php?prod_id=<?php echo $value['prod_id'];?>" class="btn btn-primary">Delete  <i class="bi bi-trash-fill"></i></a>
                            </td>
                        </tr>
                    <?php
                        }
                    ?>
                </table>
            </div>
        </div>
    </div>

<?php
    include("footer.php");
    }
    else{
        header('location:index.php');
    }
?>
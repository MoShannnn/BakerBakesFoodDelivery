<?php
    include("header.php");
    session_start();
    error_reporting(1);
    include("../connection.php");
    $username= $_POST['username'];
    $password= $_POST['password'];

    if (isset($_POST['log'])) { 
        if ($username == "" || $password == "") {
            $err = "<span style='color: white;'>Fill your username and password first</span>";
        } else {
            $sql = "SELECT * FROM admin_user WHERE username=:username AND password=:password";
            $query = $dbConn->prepare($sql);
            $query->bindParam(':username', $username);
            $query->bindParam(':password', $password);
            $query->execute();
            $result = $query->fetch();
    
            if ($result) {
                // $err = "<span style='color: white;'>Your password is Correct!!!</span>";
                $_SESSION['username'] = $result['username'];
                header("location:home.php");
                exit();
            } else {
                $err = "<span style='color: white;'>Your password is wrong!!!</span>";
            }
        }
    }
    
?>
<body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 bg-dark wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 mt-2 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
            <h3 class="text-primary" style="font-size:16pt; margin-left: 35px; margin-top: -5px;">Food Delivery</h3>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="#" class="nav-item nav-link active">Admin Page</a>
                <a href="../index.php" class="nav-item nav-link">Home</a>
            </div>
    </nav>
    <!-- Navbar End -->

    <!-- LOGIN FORM START -->
    <div class="container adminform mx-auto border border-primary rounded p-5 bg-light">
        <form method="post" action="index.php">
            <div class="mb-3">
                <label for="exampleInputusername1" class="form-label">User Name: </label>
                <input type="text" class="form-control" id="exampleInputusername1" name="username" aria-describedby="usernameHelp">
                <div id="usernameHelp" class="form-text">We'll never share your username with anyone else.</div>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password: </label>
                <input type="password" class="form-control" id="exampleInputPassword1" name="password">
            </div>
            <button type="submit" name="log" class="btn btn-primary">Log In</button>
        </form>
    </div>
    <h4 class="col-md-10 mx-auto text-center bg-primary py-2"><?php echo $err;?></h4>

    <!-- LOGIN FORM END -->
<?php
    include("footer.php");
?>
<?php
    include("header.php");
    error_reporting(1);
	include("connection.php");

    if (isset($_POST['order'])) {
        $prod_name = $_REQUEST['prod_name'];
        $prod_price = $_REQUEST['prod_price'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
    
        try {
            $stmt = $dbConn->prepare("INSERT INTO bakery_order (prod_name, prod_price, address, phone) VALUES (:prod_name, :prod_price, :address, :phone)");
            $stmt->bindParam(':prod_name', $prod_name);
            $stmt->bindParam(':prod_price', $prod_price);
            $stmt->bindParam(':address', $address);
            $stmt->bindParam(':phone', $phone);
    
            if ($stmt->execute()) {
                header("Location: order_success.php?prod_name=$prod_name");
                exit;
            } else {
                header('Location: 404.php');
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
?>
<body>
    <!-- Spinner Start -->
	  <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="menu.php" class="nav-item nav-link">Menu</a>
                <a href="about.php" class="nav-item nav-link">About</a>
                <a href="contact.php" class="nav-item nav-link">Contact</a>
                <a href="signup.php" class="btn btn-primary rounded-pill my-auto" style="margin-left: 20px;padding: 8px; width: 80px; height: 50px;">Sign Up</a>
            </div>
    </nav>
    <!-- Navbar End -->
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-6 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center pt-5 pb-3">
            <h1 class="display-4 text-white animated slideInDown mb-3">Order Form</h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Order Form -->
    <div class="container col-md-6">
        <form method="POST">
            <div class="mb-3">
                <label for="exampleInputproduct1" class="form-label">Product Name</label>
                <input type="text" class="form-control" value="<?php echo $_REQUEST['prod_name']; ?>" name="prod_name" disabled id="exampleInputproduct1">
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Price</label>
                <input type="text" class="form-control" value="<?php echo $_REQUEST['prod_price']; ?>" name="prod_price" disabled id="exampleInputPassword1">
            </div>
            <div class="mb-3">
                <label for="exampleInputAddress" class="form-label">Address</label>
                <input type="text" class="form-control" name="address" id="exampleInputAddress" required>
            </div>
            <div class="mb-3">
                <label for="exampleInputPhoneNumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" name="phone" id="exampleInputPhoneNumber" required>
            </div>
            <div class="d-flex my-5 justify-content-end">
                <button type="button" onclick="goBack()" class="btn p-2 me-3">Back</button>
                <button class="btn btn-primary" name="order" id="order" type="submit">Order</button>
            </div>
        </form>
    </div>
    <script>
        function goBack() {
        window.history.back();
        }
</script>
<?php
    include("footer.php");
?>
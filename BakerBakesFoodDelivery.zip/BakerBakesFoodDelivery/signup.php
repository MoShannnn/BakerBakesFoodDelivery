<?php
    include("header.php");
    error_reporting(1);
    include("connection.php");
    
    if (isset($_POST['createacc'])) {
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
    
        $stmt = $dbConn->prepare("SELECT * FROM register WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
    
        if ($stmt->rowCount() > 0) {
            $error = "User Email already exists";
        } else {
            $stmt = $dbConn->prepare("INSERT INTO register (first_name, last_name, email, password) VALUES (:first_name, :last_name, :email, :password)");
            $stmt->bindParam(':first_name', $first_name);
            $stmt->bindParam(':last_name', $last_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
    
            if ($stmt->execute()) {
                header("Location: reg_success.php?first_name=$first_name&last_name=$last_name");
                exit;
            } else {
                $error = "Error creating account";
            }
        }
    }
?>
<body style="background-image: url('img/product-1.jpg');background-repeat: no-repeat; background-size: cover;">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
        <a href="index.php" class="navbar-brand ms-4 mt-2 ms-lg-0">
            <h1 class="text-primary m-0">Baker Bakes
            </h1>
            <h3 class="text-primary" style="font-size:16pt; margin-left: 35px; margin-top: -5px;">Food Delivery</h3>
        </a>
            <div class="navbar-nav p-4 p-lg-0" style="margin: left;">
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="menu.php" class="nav-item nav-link">Menu</a>
                <a href="about.php" class="nav-item nav-link">About</a>
                <a href="contact.php" class="nav-item nav-link">Contact</a>
                <a href="signup.php" class="btn btn-primary rounded-pill my-auto" style="margin-left: 20px;padding: 8px; width: 80px; height: 50px;">Sign Up</a>
            </div>
    </nav>
    <!-- Navbar End -->

    <div class="container mx-auto bg-white w-50 rounded" id="reg-form">
        <div class="card-body text-center">
            <h2 class="title my-2 mb-5">Registration Form</h2>
            <form method="POST">
                <div class="row justify-content-center my-3">
                    <div class="col-lg-4">
                        <label for="exampleInput1" class="form-label">First Name</label>
                        <input type="text" class="form-control" name="first_name" id="exampleInput1" required>
                    </div>
                    <div class="col-lg-4">
                        <label for="exampleInput2" class="form-label">Last Name</label>
                        <input type="text" class="form-control" name="last_name" id="exampleInput2" required>
                    </div>
                </div>
                <div class="row justify-content-center mb-3">
                    <div class="col-md-8">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" required>
                    </div>
                </div>
                <div class="row justify-content-center mb-3">
                    <div class="col-md-8">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" id="exampleInputPassword1" required>
                    </div>
                </div>
                <div class="p-5">
                    <button class="btn btn-primary" name="createacc" id="createacc" type="submit">Create Account</button>
                    <button class="btn btn-radius-2" type="reset">Cancel</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>
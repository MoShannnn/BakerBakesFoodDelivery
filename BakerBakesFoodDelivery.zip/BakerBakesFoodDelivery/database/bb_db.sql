-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 20, 2023 at 12:11 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bb_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE IF NOT EXISTS `admin_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `username`, `password`) VALUES
(1, 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `bakery_order`
--

CREATE TABLE IF NOT EXISTS `bakery_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(255) NOT NULL,
  `prod_price` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bakery_order`
--

INSERT INTO `bakery_order` (`id`, `prod_name`, `prod_price`, `address`, `phone`) VALUES
(1, 'Bread', '$30 - $45', 'Yangon', '98888'),
(2, 'Cookies', '$29 - $55', 'Mandalay', '88888'),
(5, 'Bread', '$30 - $45', 'Bago', '000888');

-- --------------------------------------------------------

--
-- Table structure for table `contact_message`
--

CREATE TABLE IF NOT EXISTS `contact_message` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `contact_message`
--

INSERT INTO `contact_message` (`id`, `name`, `email`, `subject`, `message`) VALUES
(2, 'LILI', 'lili@gmail.com', 'customer complain', 'Blah Blah Blah..... '),
(3, 'ayeaye', 'lili@gmail.com', 'customer complain', 'ADDING MESSAGE'),
(6, 'Lily', 'lily@gmail.com', 'customer complain', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. '),
(7, 'Kyaw Kyaw', 'kyaw@gmail.com', 'product quality', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `prod_id` varchar(10) NOT NULL,
  `prod_name` varchar(30) NOT NULL,
  `prod_price` varchar(20) NOT NULL,
  `prod_description` varchar(255) NOT NULL,
  `prod_img` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prod_id`, `prod_name`, `prod_price`, `prod_description`, `prod_img`) VALUES
('p01', 'Cake\n\n', '$20 - $30', 'Cake is a flour confection made from flour, sugar, and other ingredients, and is usually baked.', 'cake.jpg'),
('p02', 'Bread', '$30 - $45', 'Bread is a staple food prepared from a dough of flour and water, usually by baking.', 'bread.jpg'),
('p03', 'Cookies', '$29 - $55', 'A cookie, or a biscuit, is a baked or cooked snack or dessert that is typically small, flat and sweet.', 'cookie.jpg'),
('p04', 'Doughnuts', '$10 - $15', 'A doughnut or donut is a type of food made from leavened fried dough. ', 'donuts.jpg'),
('p05', 'Cheesecake', '$22 - $25', 'Cheesecake is a sweet dessert consisting of one or more layers.', 'cheesecake.jpg'),
('p06', 'Pizza', '$25 - $30', 'Pizza is a dish of Italian origin consisting of a usually round, flat.', 'pizza.jpg'),
('p07', 'Bagels', '$12 - $15', 'A bagel is a bread roll originating in the Jewish communities of Poland.', 'badgel.jpg'),
('p08', 'Pastry', '$15 - $20', 'Pastry is baked food made with a dough of flour, water and shortening that may be savoury or sweetened. ', 'pastries.jpg'),
('p09', 'Biscuits', '$5 - $10', 'A biscuit is a flour-based baked and shaped food product. ', 'biscuits.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'John', 'Smit', 'johnsmit@gmail.com', '1111'),
(2, 'Li', 'ly', 'lily@gmail.com', '2222'),
(3, 'mg', 'mg', 'mgmg@gmail.com', '3333'),
(4, 'hsu', 'hsu', 'hsu@gmail.com', '4444'),
(6, 'Mr.', 'User', 'user@gmail.com', '3333');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
    $db_username = "root";
    $db_pwd = '';
    $dbConn = new PDO('mysql:host=localhost;dbname=bb_db',$db_username,$db_pwd);
?>